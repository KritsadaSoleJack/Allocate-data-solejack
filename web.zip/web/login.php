<?php
session_start();
include 'db_login.php'; // แก้เป็นชื่อไฟล์ที่ถูกต้อง

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = mysqli_real_escape_string($db_login, $_POST['username']); // แก้เป็นตัวแปรที่ถูกต้อง
    $password = mysqli_real_escape_string($db_login, $_POST['password']); // แก้เป็นตัวแปรที่ถูกต้อง

    $sql = "SELECT * FROM user WHERE Username = '$username' AND Password = '$password'";
    $result = mysqli_query($db_login, $sql);

    if ($result) {
        if (mysqli_num_rows($result) == 1) {
            $row = mysqli_fetch_assoc($result);
            $_SESSION['username'] = $row['Username'];
            $_SESSION['userlevel'] = $row['Userlevel'];
            header("location:Show.php");
        } else {
            echo "Invalid username or password.";
        }
    } else {
        echo "Error: " . mysqli_error($db_login);
    }
}
?>
