<?php
session_start(); //session_start(); เป็นการเริ่ม session ในกรณีที่ยังไม่ได้เริ่ม.
session_unset(); //session_unset(); เป็นการลบทุกตัวแปร session.
session_destroy(); //session_destroy(); เป็นการทำลาย session.

header("location: login_form.html"); //header("location: login.php"); เป็นการเปลี่ยนเส้นทาง URL ไปยังหน้า login.php.
exit(); //exit(); คือคำสั่งที่ใช้ในการหยุดการทำงานของ script ทันทีหลังจากที่ทำงานเสร็จสิ้น.
?>
