<?php
include 'db_connect.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Check if the id exists in the table
    $sqlCheckId = "SELECT id FROM repair_requests WHERE id = ?";
    $stmtCheckId = mysqli_prepare($db_connect, $sqlCheckId);
    mysqli_stmt_bind_param($stmtCheckId, "i", $id);
    mysqli_stmt_execute($stmtCheckId);
    mysqli_stmt_store_result($stmtCheckId);

    if (mysqli_stmt_num_rows($stmtCheckId) > 0) {
        // Fetch the order to delete
        $sqlGetOrder = "SELECT id FROM repair_requests WHERE id = ?";
        $stmtGetOrder = mysqli_prepare($db_connect, $sqlGetOrder);
        mysqli_stmt_bind_param($stmtGetOrder, "i", $id);
        mysqli_stmt_execute($stmtGetOrder);
        $resultGetOrder = mysqli_stmt_get_result($stmtGetOrder);
        $rowGetOrder = mysqli_fetch_assoc($resultGetOrder);
        $orderToDelete = $rowGetOrder['id'];

        // Delete the data
        $sqlDelete = "DELETE FROM repair_requests WHERE id = ?";
        $stmtDelete = mysqli_prepare($db_connect, $sqlDelete);
        mysqli_stmt_bind_param($stmtDelete, "i", $id);
        mysqli_stmt_execute($stmtDelete);

        if ($stmtDelete) {
            // Update the order
            $sqlUpdateOrder = "UPDATE repair_requests SET id = id - 1 WHERE id > ?";
            $stmtUpdateOrder = mysqli_prepare($db_connect, $sqlUpdateOrder);
            mysqli_stmt_bind_param($stmtUpdateOrder, "i", $orderToDelete);
            mysqli_stmt_execute($stmtUpdateOrder);

            echo "<script type='text/javascript'>";
            echo "alert('Delete and Reorder Successfully!');";
            echo "window.location = 'repair_list.php';";
            echo "</script>";
        } else {
            echo "<script type='text/javascript'>";
            echo "alert('Error deleting data!');";
            echo "window.location = 'repair_list.php';";
            echo "</script>";
        }
    } else {
        echo "<script type='text/javascript'>";
        echo "alert('Error: ID not found!');";
        echo "window.location = 'repair_list.php';";
        echo "</script>";
    }

    mysqli_stmt_close($stmtCheckId);
    mysqli_stmt_close($stmtGetOrder);
    mysqli_stmt_close($stmtDelete);
    mysqli_stmt_close($stmtUpdateOrder);
} else {
    echo "<script type='text/javascript'>";
    echo "alert('Error: ID not provided!');";
    echo "window.location = 'repair_list.php';";
    echo "</script>";
}

mysqli_close($db_connect);
?>
